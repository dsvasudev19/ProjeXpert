'use strict';
const {
  Model
} = require('sequelize');
module.exports = (sequelize, DataTypes) => {
  class Purchase extends Model {
    /**
     * Helper method for defining associations.
     * This method is not a part of Sequelize lifecycle.
     * The `models/index` file will call this method automatically.
     */
    static associate(models) {
      // define association here
      this.belongsTo(models.Product,{
        foreignKey:"productId"
      })
      this.belongsTo(models.User,{
        foreignKey:"userId"
      })
    }
  }
  Purchase.init({
    userId: {
      type: DataTypes.INTEGER,
      allowNull: false,
    },
    productId: {
      type: DataTypes.INTEGER,
      allowNull: false,
    },
    quantity: {
      type: DataTypes.INTEGER,
      allowNull: false,
    },
    status: {
      type: DataTypes.ENUM('Pending', 'Shipped', 'Delivered'),
      allowNull: false,
      defaultValue: 'Pending',
    }
  }, {
    sequelize,
    modelName: 'Purchase',
  });
  return Purchase;
};