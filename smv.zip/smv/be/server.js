// 'use strict';

// const express = require('express');
// const cors = require('cors');
// const jwt = require('jsonwebtoken');
// const bcrypt = require('bcrypt');
// const db = require('./models'); // Import models from index.js

// // Initialize Express app
// const app = express();
// app.use(cors());
// app.use(express.json());

// // Secret for JWT
// const JWT_SECRET = 'simple_secret_key';

// // Middleware to verify JWT
// const authenticate = (req, res, next) => {
//   const token = req.headers.authorization?.split(' ')[1];
//   if (!token) return res.status(401).json({ error: 'No token provided' });
//   try {
//     const decoded = jwt.verify(token, JWT_SECRET);
//     req.user = decoded;
//     next();
//   } catch (error) {
//     res.status(401).json({ error: 'Invalid token' });
//   }
// };

// // Register user
// app.post('/register', async (req, res) => {
//   try {
//     const { username, password, role } = req.body;
//     const hashedPassword = await bcrypt.hash(password, 10);
//     const user = await db.User.create({ username, password: hashedPassword, role });
//     res.status(201).json({ id: user.id, username, role });
//   } catch (error) {
//     res.status(400).json({ error: error.message });
//   }
// });

// // Login user
// app.post('/login', async (req, res) => {
//   try {
//     const { username, password } = req.body;
//     const user = await db.User.findOne({ where: { username } });
//     if (!user || !(await bcrypt.compare(password, user.password))) {
//       return res.status(401).json({ error: 'Invalid credentials' });
//     }
//     const token = jwt.sign({ id: user.id, role: user.role }, JWT_SECRET, { expiresIn: '1h' });
//     res.json({ token, user: { id: user.id, username, role: user.role } });
//   } catch (error) {
//     res.status(400).json({ error: error.message });
//   }
// });

// app.post('/businesses', authenticate, async (req, res) => {
//     try {
//       const { name, location, userId } = req.body;

//       // Check if user is vendor or admin
//       if (!['VENDOR', 'ADMIN'].includes(req.user.role)) {
//         return res.status(403).json({ error: 'Only vendors or admins can create businesses' });
//       }

//       // For vendors, userId must be their own; for admins, userId must be provided and valid
//       let businessUserId = req.user.id; // Default for vendors
//       if (req.user.role === 'admin') {
//         if (!userId) {
//           return res.status(400).json({ error: 'userId is required for admin-created businesses' });
//         }
//         // Validate that the provided userId exists
//         const user = await db.User.findByPk(userId);
//         if (!user) {
//           return res.status(404).json({ error: 'User with provided userId not found' });
//         }
//         businessUserId = userId; // Use provided userId for admins
//       } else if (userId && userId !== req.user.id) {
//         // Vendors cannot specify a userId other than their own
//         return res.status(403).json({ error: 'Vendors can only create businesses for themselves' });
//       }

//       // Validate required fields
//       if (!name || !location) {
//         return res.status(400).json({ error: 'Name and location are required' });
//       }

//       // Create business
//       const business = await db.Business.create({ name, location, userId: businessUserId });
//       res.status(201).json(business);
//     } catch (error) {
//       res.status(400).json({ error: error.message });
//     }
//   });



// app.get('/businesses/search', async (req, res) => {
//     try {
//       const { location } = req.query;
//       const where = {};
//       if (location) where.location = { [db.Sequelize.Op.iLike]: `%${location}%` }; // Case-insensitive search
//       const businesses = await db.Business.findAll({ where });
//       res.json(businesses);
//     } catch (error) {
//       res.status(400).json({ error: error.message });
//     }
//   });


// // Get all businesses
// app.get('/businesses', async (req, res) => {
//   try {
//     const businesses = await db.Business.findAll();
//     res.json(businesses);
//   } catch (error) {
//     res.status(400).json({ error: error.message });
//   }
// });

// // Create product (vendors only)
// app.post('/products', authenticate, async (req, res) => {
//   if (req.user.role !== 'VENDOR') return res.status(403).json({ error: 'Only vendors can create products' });
//   try {
//     const { name, price, businessId } = req.body;
//     const business = await db.Business.findOne({ where: { id: businessId } });
//     console.log(business)
//     if (!business) return res.status(403).json({ error: 'Business not found or not owned by user' });
//     const product = await db.Product.create({ name, price, businessId });
//     res.status(201).json(product);
//   } catch (error) {
//     res.status(400).json({ error: error.message });
//   }
// });

// // Get products for a business
// app.get('/businesses/:id/products', async (req, res) => {
//   try {
//     const products = await db.Product.findAll({ where: { businessId: req.params.id } });
//     res.json(products);
//   } catch (error) {
//     res.status(400).json({ error: error.message });
//   }
// });

// // Create purchase (customers only)
// app.post('/purchases', authenticate, async (req, res) => {
//   if (req.user.role !== 'customer') return res.status(403).json({ error: 'Only customers can make purchases' });
//   try {
//     const { productId, quantity } = req.body;
//     const product = await db.Product.findByPk(productId);
//     if (!product) return res.status(404).json({ error: 'Product not found' });
//     const purchase = await db.Purchase.create({ userId: req.user.id, productId, quantity });
//     res.status(201).json(purchase);
//   } catch (error) {
//     res.status(400).json({ error: error.message });
//   }
// });

// // Get user purchases
// app.get('/purchases', authenticate, async (req, res) => {
//   try {
//     const purchases = await db.Purchase.findAll({
//       where: { userId: req.user.id },
//       include: [{ model: db.Product }],
//     });
//     res.json(purchases);
//   } catch (error) {
//     res.status(400).json({ error: error.message });
//   }
// });

// // Sync database
// db.sequelize.sync({ force: false }).then(() => {
//   console.log('Database synced');
// });

// // Start server
// const PORT = 3000;
// app.listen(PORT, () => {
//   console.log(`Server running on port ${PORT}`);
// });


'use strict';

const express = require('express');
const cors = require('cors');
const jwt = require('jsonwebtoken');
const bcrypt = require('bcrypt');
const multer = require('multer');
const path = require('path');
const db = require('./models'); // Import models from index.js

// Initialize Express app
const app = express();
app.use(cors());
app.use(express.json());

// Serve static files from the uploads directory
app.use('/uploads', express.static(path.join(__dirname, 'uploads')));

// Multer storage configuration
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, 'uploads/');
  },
  filename: (req, file, cb) => {
    const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1e9);
    cb(null, `${file.fieldname}-${uniqueSuffix}${path.extname(file.originalname)}`);
  },
});

const upload = multer({
  storage,
  fileFilter: (req, file, cb) => {
    const filetypes = /jpeg|jpg|png/;
    const extname = filetypes.test(path.extname(file.originalname).toLowerCase());
    const mimetype = filetypes.test(file.mimetype);
    if (extname && mimetype) {
      return cb(null, true);
    } else {
      cb(new Error('Only JPEG and PNG images are allowed'));
    }
  },
  limits: { fileSize: 5 * 1024 * 1024 }, // 5MB limit
});

// Secret for JWT
const JWT_SECRET = 'simple_secret_key';

// Middleware to verify JWT
const authenticate = (req, res, next) => {
  const token = req.headers.authorization?.split(' ')[1];
  if (!token) return res.status(401).json({ error: 'No token provided' });
  try {
    const decoded = jwt.verify(token, JWT_SECRET);
    req.user = decoded;
    next();
  } catch (error) {
    res.status(401).json({ error: 'Invalid token' });
  }
};

// Register user
app.post('/register', async (req, res) => {
  try {
    const { username, password, role } = req.body;
    if (!username || !password || !role) {
      return res.status(400).json({ error: 'Username, password, and role are required' });
    }
    if (!['CUSTOMER', 'VENDOR', 'ADMIN'].includes(role)) {
      return res.status(400).json({ error: 'Invalid role' });
    }
    const hashedPassword = await bcrypt.hash(password, 10);
    const user = await db.User.create({ username, password: hashedPassword, role });
    res.status(201).json({ id: user.id, username, role });
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
});

// Login user
app.post('/login', async (req, res) => {
  try {
    const { username, password } = req.body;
    if (!username || !password) {
      return res.status(400).json({ error: 'Username and password are required' });
    }
    const user = await db.User.findOne({ where: { username } });
    if (!user || !(await bcrypt.compare(password, user.password))) {
      return res.status(401).json({ error: 'Invalid credentials' });
    }
    const token = jwt.sign({ id: user.id, role: user.role }, JWT_SECRET, { expiresIn: '1h' });
    res.json({ token, user: { id: user.id, username, role: user.role } });
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
});

// Create business with image
app.post('/businesses', authenticate, upload.single('image'), async (req, res) => {
  try {
    const { name, location, userId } = req.body;

    // Check if user is VENDOR or ADMIN
    if (!['VENDOR', 'ADMIN'].includes(req.user.role)) {
      return res.status(403).json({ error: 'Only vendors or admins can create businesses' });
    }

    // For vendors, userId must be their own; for admins, userId must be provided and valid
    let businessUserId = req.user.id;
    if (req.user.role === 'ADMIN') {
      if (!userId) {
        return res.status(400).json({ error: 'userId is required for admin-created businesses' });
      }
      const user = await db.User.findByPk(userId);
      if (!user) {
        return res.status(404).json({ error: 'User with provided userId not found' });
      }
      businessUserId = userId;
    } else if (userId && userId !== req.user.id) {
      return res.status(403).json({ error: 'Vendors can only create businesses for themselves' });
    }

    // Validate required fields
    if (!name || !location) {
      return res.status(400).json({ error: 'Name and location are required' });
    }

    // Get image path if uploaded
    const image = req.file ? `/uploads/${req.file.filename}` : null;

    // Create business
    const business = await db.Business.create({ name, location, userId: businessUserId, image });
    res.status(201).json(business);
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
});

// Update business
app.put('/businesses/:id', authenticate, upload.single('image'), async (req, res) => {
  try {
    const { id } = req.params;
    const { name, location } = req.body;
    const business = await db.Business.findByPk(id);
    if (!business) {
      return res.status(404).json({ error: 'Business not found' });
    }

    // Check authorization
    if (req.user.role !== 'ADMIN' && business.userId !== req.user.id) {
      return res.status(403).json({ error: 'Not authorized to update this business' });
    }

    // Update fields
    business.name = name || business.name;
    business.location = location || business.location;
    business.image = req.file ? `/uploads/${req.file.filename}` : business.image;

    await business.save();
    res.json(business);
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
});

// Delete business
app.delete('/businesses/:id', authenticate, async (req, res) => {
  try {
    const { id } = req.params;
    const business = await db.Business.findByPk(id);
    if (!business) {
      return res.status(404).json({ error: 'Business not found' });
    }

    // Check authorization
    if (req.user.role !== 'ADMIN' && business.userId !== req.user.id) {
      return res.status(403).json({ error: 'Not authorized to delete this business' });
    }

    // Check for associated products
    const products = await db.Product.findAll({ where: { businessId: id } });
    if (products.length > 0) {
      return res.status(400).json({ error: 'Cannot delete business with associated products' });
    }

    await business.destroy();
    res.json({ message: 'Business deleted successfully' });
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
});

// Search businesses
app.get('/businesses/search', async (req, res) => {
  try {
    const { location } = req.query;
    const where = {};
    if (location) where.location = { [db.Sequelize.Op.iLike]: `%${location}%` };
    const businesses = await db.Business.findAll({ where });
    res.json(businesses);
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
});

// Get all businesses
app.get('/businesses', async (req, res) => {
  try {
    const businesses = await db.Business.findAll();
    res.json(businesses);
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
});

app.get('/businesses/:id', async (req, res) => {
    try {
      const { id } = req.params;
  
      const business = await db.Business.findByPk(id);
  
      if (!business) {
        return res.status(404).json({ error: 'Business not found' });
      }
  
      res.json(business);
    } catch (error) {
      res.status(400).json({ error: error.message });
    }
  });
  

app.get('/products/:id', authenticate, async (req, res) => {

    try {
      const { id } = req.params;
  
      // Find the product by ID
      const product = await db.Product.findByPk(id);
  
      if (!product) {
        return res.status(404).json({ error: 'Product not found' });
      }
  
      // Check if the product belongs to a business owned by the user
      const business = await db.Business.findOne({
        where: { id: product.businessId }
      });
  
      if (!business) {
        return res.status(403).json({ error: 'Not authorized to view this product' });
      }
  
      res.json(product);
    } catch (error) {
      res.status(400).json({ error: error.message });
    }
  });

  
// Create product with image
app.post('/products', authenticate, upload.single('image'), async (req, res) => {
  if (req.user.role !== 'VENDOR') {
    return res.status(403).json({ error: 'Only vendors can create products' });
  }
  console.log("user is ")
  console.log(req.user)
  try {
    const { name, price, businessId } = req.body;
    if (!name || !price || !businessId) {
      return res.status(400).json({ error: 'Name, price, and businessId are required' });
    }
    const business = await db.Business.findOne({ where: { id: businessId, userId: req.user.id } });
    if (!business) {
      return res.status(403).json({ error: 'Business not found or not owned by user' });
    }
    const image = req.file ? `/uploads/${req.file.filename}` : null;
    const product = await db.Product.create({ name, price, businessId, image });
    res.status(201).json(product);
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
});

// Update product
app.put('/products/:id', authenticate, upload.single('image'), async (req, res) => {
  if (req.user.role !== 'VENDOR') {
    return res.status(403).json({ error: 'Only vendors can update products' });
  }
  try {
    const { id } = req.params;
    const { name, price, businessId } = req.body;
    const product = await db.Product.findByPk(id);
    if (!product) {
      return res.status(404).json({ error: 'Product not found' });
    }
    const business = await db.Business.findOne({ where: { id: product.businessId, userId: req.user.id } });
    if (!business) {
      return res.status(403).json({ error: 'Not authorized to update this product' });
    }
    product.name = name || product.name;
    product.price = price || product.price;
    product.businessId = businessId || product.businessId;
    product.image = req.file ? `/uploads/${req.file.filename}` : product.image;
    await product.save();
    res.json(product);
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
});

// Delete product
app.delete('/products/:id', authenticate, async (req, res) => {
  if (req.user.role !== 'VENDOR') {
    return res.status(403).json({ error: 'Only vendors can delete products' });
  }
  try {
    const { id } = req.params;
    const product = await db.Product.findByPk(id);
    if (!product) {
      return res.status(404).json({ error: 'Product not found' });
    }
    const business = await db.Business.findOne({ where: { id: product.businessId, userId: req.user.id } });
    if (!business) {
      return res.status(403).json({ error: 'Not authorized to delete this product' });
    }
    // Check for associated purchases
    const purchases = await db.Purchase.findAll({ where: { productId: id } });
    if (purchases.length > 0) {
      return res.status(400).json({ error: 'Cannot delete product with associated purchases' });
    }
    await product.destroy();
    res.json({ message: 'Product deleted successfully' });
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
});

// Get products for a business
app.get('/businesses/:id/products', async (req, res) => {
  try {
    const products = await db.Product.findAll({ where: { businessId: req.params.id } });
    res.json(products);
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
});

// Create purchase
app.post('/purchases', authenticate, async (req, res) => {
    if (req.user.role !== 'CUSTOMER') {
      return res.status(403).json({ error: 'Only customers can make purchases' });
    }
  
    try {
      const { productId, quantity } = req.body;
  
      if (!productId || !quantity || quantity <= 0) {
        return res.status(400).json({ error: 'Product ID and valid quantity are required' });
      }
  
      // Fetch the product to verify it exists and get its businessId
      const product = await db.Product.findByPk(productId);
  
      if (!product) {
        return res.status(404).json({ error: 'Product not found' });
      }
  
      // Create the purchase with businessId attached
      const purchase = await db.Purchase.create({
        userId: req.user.id,
        productId,
        quantity,
        businessId: product.businessId
      });
  
      res.status(201).json(purchase);
    } catch (error) {
      res.status(400).json({ error: error.message });
    }
  });
  

// Update purchase
app.put('/purchases/:id', authenticate, async (req, res) => {
    try {
      const { id } = req.params;
      const { quantity, status } = req.body;
      const purchase = await db.Purchase.findByPk(id);
      if (!purchase) return res.status(404).json({ error: 'Purchase not found' });
      if (req.user.role === 'CUSTOMER' && purchase.userId !== req.user.id) {
        return res.status(403).json({ error: 'Not authorized to update this purchase' });
      }
      if (req.user.role === 'VENDOR') {
        const product = await db.Product.findByPk(purchase.productId);
        const business = await db.Business.findByPk(product.businessId);
        if (business.userId !== req.user.id) return res.status(403).json({ error: 'Not authorized to update this purchase' });
      }
      if (quantity !== undefined && quantity <= 0) return res.status(400).json({ error: 'Quantity must be greater than 0' });
      if (status && !['Pending', 'Shipped', 'Delivered'].includes(status)) return res.status(400).json({ error: 'Invalid status' });
      purchase.quantity = quantity !== undefined ? quantity : purchase.quantity;
      purchase.status = status || purchase.status;
      await purchase.save();
      res.json(purchase);
    } catch (error) {
      res.status(400).json({ error: error.message });
    }
  });
  
  app.delete('/purchases/:id', authenticate, async (req, res) => {
    try {
      const { id } = req.params;
      const purchase = await db.Purchase.findByPk(id);
      if (!purchase) return res.status(404).json({ error: 'Purchase not found' });
      if (req.user.role === 'CUSTOMER' && purchase.userId !== req.user.id) {
        return res.status(403).json({ error: 'Not authorized to delete this purchase' });
      }
      if (req.user.role === 'VENDOR') {
        const product = await db.Product.findByPk(purchase.productId);
        const business = await db.Business.findByPk(product.businessId);
        if (business.userId !== req.user.id) return res.status(403).json({ error: 'Not authorized to delete this purchase' });
      }
      await purchase.destroy();
      res.json({ message: 'Purchase deleted successfully' });
    } catch (error) {
      res.status(400).json({ error: error.message });
    }
  });
// Get user purchases
app.get('/purchases', authenticate, async (req, res) => {
    try {
      if (req.user.role === 'CUSTOMER') {
        const purchases = await db.Purchase.findAll({
          where: { userId: req.user.id },
          include: [{ model: db.Product }],
        });
        res.json(purchases);
      } else if (req.user.role === 'VENDOR') {
        const businesses = await db.Business.findAll({ where: { userId: req.user.id },include:[
            {
                model:db.Product
            },
            {
                model:db.User
            }
        ] });
        const businessIds = businesses.map(b => b.id);
        const products = await db.Product.findAll({ where: { businessId: businessIds } });
        const productIds = products.map(p => p.id);
        const purchases = await db.Purchase.findAll({
          where: { productId: productIds },
          include: [{ model: db.Product }],
        });
        res.json(purchases);
      } else {
        return res.status(403).json({ error: 'Only customers and vendors can view purchases' });
      }
    } catch (error) {
      res.status(400).json({ error: error.message });
    }
  });
  

app.get('/users', authenticate, async (req, res) => {
    if (req.user.role !== 'ADMIN') {
      return res.status(403).json({ error: 'Only admins can access user list' });
    }
    try {
      const users = await db.User.findAll({
        attributes: ['id', 'username', 'role'],
      });
      res.json(users);
    } catch (error) {
      res.status(400).json({ error: error.message });
    }
  });

// Sync database
db.sequelize.sync({ force: false }).then(() => {
  console.log('Database synced');
});

// Start server
const PORT = 3000;
app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});