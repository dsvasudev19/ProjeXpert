import { useState, useEffect } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import axios from 'axios';

function Home() {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [message, setMessage] = useState('');
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [userRole, setUserRole] = useState('');
  const navigate = useNavigate();

  // Check authentication status
  useEffect(() => {
    const token = localStorage.getItem('token');
    const role = localStorage.getItem('role');
    if (token && role) {
      setIsLoggedIn(true);
      setUserRole(role);
    }
  }, []);

  // Clear messages after 3 seconds
  useEffect(() => {
    if (error || success) {
      const timer = setTimeout(() => {
        setError('');
        setSuccess('');
      }, 3000);
      return () => clearTimeout(timer);
    }
  }, [error, success]);

  // Handle contact form submission
  const handleContactSubmit = async (e) => {
    e.preventDefault();
    if (!name || !email || !message) {
      setError('All fields are required.');
      return;
    }
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
      setError('Please enter a valid email address.');
      return;
    }
    try {
      // Placeholder API call (replace with actual endpoint if available)
      await axios.post('http://localhost:3000/contact', { name, email, message });
      setSuccess('Message sent successfully!');
      setName('');
      setEmail('');
      setMessage('');
    } catch (error) {
      setError('Failed to send message. Please try again.');
    }
  };

  // Handle logout
  const handleLogout = () => {
    localStorage.removeItem('token');
    localStorage.removeItem('role');
    localStorage.removeItem('userId');
    setIsLoggedIn(false);
    setUserRole('');
    navigate('/');
  };

  // Handle dashboard redirect based on role
  const handleDashboardRedirect = () => {
    if (userRole === 'ADMIN') {
      navigate('/admin');
    } else if (userRole === 'VENDOR') {
      navigate('/vendor');
    } else {
      navigate('/businesses');
    }
  };

  // Smooth scroll to section
  const scrollToSection = (id) => {
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-green-50 to-orange-50">
      {/* Navbar */}
      <nav className="bg-green-800 text-white fixed w-full z-10 top-0 shadow-lg">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex-shrink-0">
              <Link to="/" className="text-2xl font-bold tracking-tight">
                Village Commerce
              </Link>
            </div>
            <div className="hidden md:flex space-x-4 items-center">
              <button
                onClick={() => navigate('/businesses')}
                className="px-4 py-2 bg-orange-500 text-white rounded-lg hover:bg-orange-600 transition transform hover:scale-105"
              >
                Explore Stores
              </button>
              <button
                onClick={() => scrollToSection('about')}
                className="px-4 py-2 hover:text-orange-300 transition"
              >
                About
              </button>
              <button
                onClick={() => scrollToSection('contact')}
                className="px-4 py-2 hover:text-orange-300 transition"
              >
                Contact
              </button>
              {isLoggedIn ? (
                <>
                  <button
                    onClick={handleDashboardRedirect}
                    className="px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition transform hover:scale-105"
                  >
                    Dashboard
                  </button>
                  <button
                    onClick={handleLogout}
                    className="px-4 py-2 bg-red-500 text-white rounded-lg hover:bg-red-600 transition transform hover:scale-105"
                  >
                    Logout
                  </button>
                </>
              ) : (
                <>
                  <Link
                    to="/login"
                    className="px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition transform hover:scale-105"
                  >
                    Login
                  </Link>
                  <Link
                    to="/register"
                    className="px-4 py-2 bg-orange-600 text-white rounded-lg hover:bg-orange-700 transition transform hover:scale-105"
                  >
                    Register
                  </Link>
                </>
              )}
            </div>
            {/* Mobile Menu Button */}
            <div className="md:hidden">
              <button
                onClick={() => document.getElementById('mobile-menu').classList.toggle('hidden')}
                className="p-2 rounded-md hover:bg-green-700"
              >
                <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M4 6h16M4 12h16m-7 6h7" />
                </svg>
              </button>
            </div>
          </div>
        </div>
        {/* Mobile Menu */}
        <div id="mobile-menu" className="md:hidden hidden bg-green-700">
          <div className="px-2 pt-2 pb-3 space-y-1 sm:px-3">
            <button
              onClick={() => navigate('/businesses')}
              className="block w-full text-left px-3 py-2 text-white hover:bg-orange-500 rounded-lg"
            >
              Explore Stores
            </button>
            <button
              onClick={() => scrollToSection('about')}
              className="block w-full text-left px-3 py-2 text-white hover:bg-green-600 rounded-lg"
            >
              About
            </button>
            <button
              onClick={() => scrollToSection('contact')}
              className="block w-full text-left px-3 py-2 text-white hover:bg-green-600 rounded-lg"
            >
              Contact
            </button>
            {isLoggedIn ? (
              <>
                <button
                  onClick={handleDashboardRedirect}
                  className="block w-full text-left px-3 py-2 text-white hover:bg-green-600 rounded-lg"
                >
                  Dashboard
                </button>
                <button
                  onClick={handleLogout}
                  className="block w-full text-left px-3 py-2 text-white hover:bg-red-500 rounded-lg"
                >
                  Logout
                </button>
              </>
            ) : (
              <>
                <Link
                  to="/login"
                  className="block px-3 py-2 text-white hover:bg-green-600 rounded-lg"
                >
                  Login
                </Link>
                <Link
                  to="/register"
                  className="block px-3 py-2 text-white hover:bg-orange-500 rounded-lg"
                >
                  Register
                </Link>
              </>
            )}
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="pt-24 pb-16 bg-gradient-to-r from-green-600 to-orange-500 text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h1 className="text-5xl md:text-6xl font-extrabold tracking-tight animate-fade-in-up">
            Discover Local Treasures with Village Commerce
          </h1>
          <p className="mt-6 text-xl md:text-2xl max-w-3xl mx-auto animate-fade-in-up animation-delay-200">
            Connect with local businesses, shop unique products, and support your community like never before!
          </p>
          <button
            onClick={() => navigate('/businesses')}
            className="mt-8 px-8 py-4 bg-white text-green-800 font-semibold rounded-lg shadow-lg hover:bg-orange-100 transition transform hover:scale-105 animate-fade-in-up animation-delay-400"
          >
            Explore Stores Now
          </button>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-4xl font-extrabold text-center text-green-800 mb-12">
            Why Choose Village Commerce?
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="p-6 bg-green-50 rounded-lg shadow-md hover:shadow-lg transition transform hover:-translate-y-1">
              <svg className="w-12 h-12 text-orange-500 mb-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v2h5m-2-2a3 3 0 005.356 1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z" />
              </svg>
              <h3 className="text-xl font-semibold text-green-800">Support Local</h3>
              <p className="mt-2 text-gray-600">
                Discover and shop from local vendors, strengthening your community’s economy.
              </p>
            </div>
            <div className="p-6 bg-green-50 rounded-lg shadow-md hover:shadow-lg transition transform hover:-translate-y-1">
              <svg className="w-12 h-12 text-orange-500 mb-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M16 11V7a4 4 0 00-8 0v4M5 9h14l1 12H4L5 9z" />
              </svg>
              <h3 className="text-xl font-semibold text-green-800">Secure Shopping</h3>
              <p className="mt-2 text-gray-600">
                Purchase products with confidence using our secure, authenticated platform.
              </p>
            </div>
            <div className="p-6 bg-green-50 rounded-lg shadow-md hover:shadow-lg transition transform hover:-translate-y-1">
              <svg className="w-12 h-12 text-orange-500 mb-4" fill="none" stroke="currentColor" viewBox="0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2m-3 7h3m-3 4h3m-6-4h.01m-.01 4h.01" />
              </svg>
              <h3 className="text-xl font-semibold text-green-800">Vendor Tools</h3>
              <p className="mt-2 text-gray-600">
                Manage your business, products, and orders with our powerful vendor dashboard.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* About Section */}
      <section id="about" className="py-16 bg-orange-100">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-4xl font-extrabold text-green-800 mb-8">About Village Commerce</h2>
          <p className="text-lg text-gray-600 max-w-3xl mx-auto">
            Village Commerce is your gateway to vibrant local markets. Our mission is to empower small businesses and connect communities through a seamless, secure, and engaging online marketplace. Whether you’re a customer seeking unique products or a vendor looking to grow, we’re here to make commerce personal, local, and exciting!
          </p>
        </div>
      </section>

      {/* Contact Section */}
      <section id="contact" className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-4xl font-extrabold text-center text-green-800 mb-12">Get in Touch</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <div>
              <h3 className="text-2xl font-semibold text-green-800 mb-4">Contact Us</h3>
              <p className="text-gray-600 mb-4">
                Have questions or feedback? Reach out to us, and we’ll get back to you as soon as possible!
              </p>
              <p className="text-gray-600">
                <strong>Email:</strong> support@villagecommerce.com
              </p>
              <p className="text-gray-600">
                <strong>Phone:</strong> (123) 456-7890
              </p>
              <p className="text-gray-600">
                <strong>Address:</strong> 123 Village Lane, Community City, VC 12345
              </p>
            </div>
            <div>
              {/* Messages */}
              {error && (
                <div className="mb-6 p-4 bg-red-100 text-red-700 rounded-lg">
                  {error}
                </div>
              )}
              {success && (
                <div className="mb-6 p-4 bg-green-100 text-green-700 rounded-lg">
                  {success}
                </div>
              )}
              {/* Contact Form */}
              <form onSubmit={handleContactSubmit} className="space-y-6">
                <div>
                  <label htmlFor="name" className="block text-sm font-medium text-gray-700">
                    Name
                  </label>
                  <input
                    id="name"
                    type="text"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    className="mt-1 w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-400 focus:outline-none"
                    placeholder="Your name"
                    required
                    aria-required="true"
                  />
                </div>
                <div>
                  <label htmlFor="email" className="block text-sm font-medium text-gray-700">
                    Email
                  </label>
                  <input
                    id="email"
                    type="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    className="mt-1 w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-400 focus:outline-none"
                    placeholder="Your email"
                    required
                    aria-required="true"
                  />
                </div>
                <div>
                  <label htmlFor="message" className="block text-sm font-medium text-gray-700">
                    Message
                  </label>
                  <textarea
                    id="message"
                    value={message}
                    onChange={(e) => setMessage(e.target.value)}
                    className="mt-1 w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-400 focus:outline-none"
                    placeholder="Your message"
                    rows="4"
                    required
                    aria-required="true"
                  ></textarea>
                </div>
                <button
                  type="submit"
                  className="w-full py-3 bg-orange-500 text-white rounded-lg hover:bg-orange-600 transition disabled:bg-orange-300"
                  disabled={!name || !email || !message}
                >
                  Send Message
                </button>
              </form>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-green-800 text-white py-8">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <p className="text-lg font-semibold">Village Commerce</p>
          <div className="mt-4 flex justify-center space-x-6">
            <button
              onClick={() => scrollToSection('about')}
              className="hover:text-orange-300 transition"
            >
              About
            </button>
            <button
              onClick={() => scrollToSection('contact')}
              className="hover:text-orange-300 transition"
            >
              Contact
            </button>
            <Link to="/register" className="hover:text-orange-300 transition">
              Register
            </Link>
            <Link to="/login" className="hover:text-orange-300 transition">
              Login
            </Link>
          </div>
          <p className="mt-4 text-sm">
            &copy; 2025 Village Commerce. All rights reserved.
          </p>
        </div>
      </footer>
    </div>
  );
}

export default Home;