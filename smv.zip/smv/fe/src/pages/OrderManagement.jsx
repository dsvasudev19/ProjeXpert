import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';

function OrderManagement() {
  const [orders, setOrders] = useState([]);
  const [filteredOrders, setFilteredOrders] = useState([]);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState('');
  const [sortConfig, setSortConfig] = useState({ key: 'id', direction: 'asc' });
  const navigate = useNavigate();

  useEffect(() => {
    const fetchOrders = async () => {
      try {
        const token = localStorage.getItem('token');
        if (!token || localStorage.getItem('role') !== 'VENDOR') {
          navigate('/login');
          return;
        }
        const response = await axios.get('http://localhost:3000/purchases', {
          headers: { Authorization: `Bearer ${token}` },
        });
        setOrders(response.data);
        setFilteredOrders(response.data);
      } catch (error) {
        setError(error.response?.data?.error || 'Failed to fetch orders.');
      }
    };
    fetchOrders();
  }, [navigate]);

  useEffect(() => {
    if (error || success) {
      const timer = setTimeout(() => {
        setError('');
        setSuccess('');
      }, 3000);
      return () => clearTimeout(timer);
    }
  }, [error, success]);

  // Filter and search orders
  useEffect(() => {
    let result = [...orders];
    if (searchTerm) {
      result = result.filter(
        (order) =>
          order.Product.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
          order.userId.toString().includes(searchTerm)
      );
    }
    if (statusFilter) {
      result = result.filter((order) => order.status === statusFilter);
    }
    setFilteredOrders(result);
  }, [searchTerm, statusFilter, orders]);

  // Sort orders
  const handleSort = (key) => {
    let direction = 'asc';
    if (sortConfig.key === key && sortConfig.direction === 'asc') {
      direction = 'desc';
    }
    setSortConfig({ key, direction });
    setFilteredOrders(
      [...filteredOrders].sort((a, b) => {
        if (key === 'total') {
          const aTotal = a.quantity * a.productPrice;
          const bTotal = b.quantity * b.productPrice;
          return direction === 'asc' ? aTotal - bTotal : bTotal - aTotal;
        }
        if (a[key] < b[key]) return direction === 'asc' ? -1 : 1;
        if (a[key] > b[key]) return direction === 'asc' ? 1 : -1;
        return 0;
      })
    );
  };

  // Update order status
  const handleStatusUpdate = async (orderId, newStatus) => {
    try {
      const token = localStorage.getItem('token');
      await axios.put(
        `http://localhost:3000/purchases/${orderId}`,
        { status: newStatus },
        { headers: { Authorization: `Bearer ${token}` } }
      );
      setOrders(
        orders.map((order) =>
          order.id === orderId ? { ...order, status: newStatus } : order
        )
      );
      setFilteredOrders(
        filteredOrders.map((order) =>
          order.id === orderId ? { ...order, status: newStatus } : order
        )
      );
      setSuccess('Order status updated successfully!');
    } catch (error) {
      setError(error.response?.data?.error || 'Failed to update order status.');
    }
  };

  // Update order quantity
  const handleQuantityUpdate = async (orderId, newQuantity) => {
    if (newQuantity < 1) {
      setError('Quantity must be at least 1.');
      return;
    }
    try {
      const token = localStorage.getItem('token');
      await axios.put(
        `http://localhost:3000/purchases/${orderId}`,
        { quantity: newQuantity },
        { headers: { Authorization: `Bearer ${token}` } }
      );
      setOrders(
        orders.map((order) =>
          order.id === orderId ? { ...order, quantity: newQuantity } : order
        )
      );
      setFilteredOrders(
        filteredOrders.map((order) =>
          order.id === orderId ? { ...order, quantity: newQuantity } : order
        )
      );
      setSuccess('Order quantity updated successfully!');
    } catch (error) {
      setError(error.response?.data?.error || 'Failed to update order quantity.');
    }
  };

  // Delete order
  const handleDelete = async (orderId) => {
    if (!window.confirm('Are you sure you want to delete this order?')) return;
    try {
      const token = localStorage.getItem('token');
      await axios.delete(`http://localhost:3000/purchases/${orderId}`, {
        headers: { Authorization: `Bearer ${token}` },
      });
      setOrders(orders.filter((order) => order.id !== orderId));
      setFilteredOrders(filteredOrders.filter((order) => order.id !== orderId));
      setSuccess('Order deleted successfully!');
    } catch (error) {
      setError(error.response?.data?.error || 'Failed to delete order.');
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-green-50 to-orange-50 py-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-7xl mx-auto">
        <h2 className="text-4xl font-extrabold text-center text-green-800 mb-8">Manage Orders</h2>

        {/* Messages */}
        {(error || success) && (
          <div className={`mb-6 p-4 rounded-lg text-center animate-fade-in-up ${error ? 'bg-red-100 text-red-700' : 'bg-green-100 text-green-700'}`}>
            {error || success}
          </div>
        )}

        {/* Filters and Search */}
        <div className="mb-6 flex flex-col sm:flex-row gap-4">
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="Search by product or customer ID..."
            className="flex-1 p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-400 focus:outline-none"
          />
          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
            className="w-full sm:w-48 p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-400 focus:outline-none"
          >
            <option value="">All Statuses</option>
            <option value="Pending">Pending</option>
            <option value="Shipped">Shipped</option>
            <option value="Delivered">Delivered</option>
          </select>
        </div>

        {/* Order Table */}
        {filteredOrders.length === 0 ? (
          <p className="text-center text-gray-600 text-lg">No orders found.</p>
        ) : (
          <div className="overflow-x-auto bg-white rounded-lg shadow-xl">
            <table className="min-w-full divide-y divide-gray-200">
              <thead className="bg-green-800 text-white">
                <tr>
                  {['id', 'productName', 'productPrice', 'quantity', 'total', 'userId', 'status', 'actions'].map((key) => (
                    <th
                      key={key}
                      onClick={() => key !== 'actions' && handleSort(key === 'productName' ? 'productName' : key === 'productPrice' ? 'productPrice' : key === 'userId' ? 'userId' : key)}
                      className="px-6 py-3 text-left text-sm font-medium uppercase tracking-wider cursor-pointer hover:bg-green-700"
                    >
                      {key === 'id' ? 'Order ID' : 
                       key === 'productName' ? 'Product' : 
                       key === 'productPrice' ? 'Price' : 
                       key === 'userId' ? 'Customer ID' : 
                       key === 'total' ? 'Total' : 
                       key === 'status' ? 'Status' : 
                       key === 'actions' ? 'Actions' : key}
                      {key !== 'actions' && (
                        <span className="ml-2">{sortConfig.key === (key === 'productName' ? 'productName' : key === 'productPrice' ? 'productPrice' : key === 'userId' ? 'userId' : key) ? (sortConfig.direction === 'asc' ? '↑' : '↓') : ''}</span>
                      )}
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-gray-200">
                {filteredOrders.map((order) => (
                  <tr key={order.id} className="hover:bg-green-50 transition">
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">{order.id}</td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900 flex items-center">
                      {order.Product.image && (
                        <img
                          src={`http://localhost:3000${order.Product.image}`}
                          alt={order.Product.name}
                          className="w-10 h-10 object-cover rounded-full mr-2"
                        />
                      )}
                      {order.Product.name}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">${order?.Product.price?.toFixed(2)}</td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                      <input
                        type="number"
                        value={order.quantity}
                        onChange={(e) => handleQuantityUpdate(order.id, parseInt(e.target.value) || 1)}
                        className="w-16 p-1 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-400"
                        min="1"
                      />
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">${(order?.Product?.price * order.quantity)?.toFixed(2)}</td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">{order.userId}</td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm">
                      <select
                        value={order.status}
                        onChange={(e) => handleStatusUpdate(order.id, e.target.value)}
                        className={`p-1 rounded-lg border ${order.status === 'Pending' ? 'border-orange-300 bg-orange-100' : order.status === 'Shipped' ? 'border-blue-300 bg-blue-100' : 'border-green-300 bg-green-100'}`}
                      >
                        <option value="Pending">Pending</option>
                        <option value="Shipped">Shipped</option>
                        <option value="Delivered">Delivered</option>
                      </select>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm">
                      <button
                        onClick={() => handleDelete(order.id)}
                        className="text-red-600 hover:text-red-800 transition"
                      >
                        Delete
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
}

export default OrderManagement;