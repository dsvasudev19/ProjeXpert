// import React, { useState, useEffect } from 'react';
// import { useParams, Link } from 'react-router-dom';
// import axios from 'axios';

// const ProductListing = () => {
//   const { id } = useParams(); // Get businessId from URL
//   const [products, setProducts] = useState([]);
//   const [business, setBusiness] = useState(null);
//   const [loading, setLoading] = useState(true);
//   const [error, setError] = useState('');

//   useEffect(() => {
//     const fetchData = async () => {
//       setLoading(true);
//       setError('');
//       try {
//         // Fetch business details
//         // const businessResponse = await axios.get(`http://localhost:3000/businesses/${id}`);
//         // setBusiness(businessResponse.data);
//         // Fetch products for the business
//         const productsResponse = await axios.get(`http://localhost:3000/businesses/${id}/products`);
//         setProducts(productsResponse.data);
//       } catch (err) {
//         setError(err.response?.data?.error || 'Failed to load products. Please try again.');
//       } finally {
//         setLoading(false);
//       }
//     };
//     fetchData();
//   }, [id]);

//   return (
//     <div className="min-h-screen bg-white py-12 px-4 sm:px-6 lg:px-8">
//       <div className="max-w-7xl mx-auto">
//         {/* Header */}
//         <div className="mb-8">
//           <Link
//             to="/businesses"
//             className="inline-flex items-center text-sm font-medium text-orange-600 hover:underline"
//           >
//             <svg
//               className="w-5 h-5 mr-2"
//               fill="none"
//               stroke="currentColor"
//               viewBox="0 0 24 24"
//               xmlns="http://www.w3.org/2000/svg"
//             >
//               <path
//                 strokeLinecap="round"
//                 strokeLinejoin="round"
//                 strokeWidth="2"
//                 d="M15 19l-7-7 7-7"
//               />
//             </svg>
//             Back to Businesses
//           </Link>
//           <h1 className="mt-4 text-3xl font-extrabold text-gray-900">
//             {business ? `${business.name} - Products` : 'Loading Business...'}
//           </h1>
//           {business && (
//             <p className="mt-2 text-sm text-gray-600">
//               Location: {business.location}
//             </p>
//           )}
//         </div>

//         {/* Error Message */}
//         {error && (
//           <div className="mb-6 text-red-500 text-center text-sm">{error}</div>
//         )}

//         {/* Loading State */}
//         {loading && (
//           <div className="text-center text-gray-600">Loading products...</div>
//         )}

//         {/* Products Grid */}
//         {!loading && !error && products.length === 0 && (
//           <div className="text-center text-gray-600">
//             No products available for this business.
//           </div>
//         )}
//         {!loading && !error && products.length > 0 && (
//           <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
//             {products.map((product) => (
//               <div
//                 key={product.id}
//                 className="bg-white border border-gray-200 rounded-lg shadow-md overflow-hidden"
//               >
//                 {product.imageUrl ? (
//                   <img
//                     src={product.imageUrl}
//                     alt={product.name}
//                     className="w-full h-48 object-cover"
//                   />
//                 ) : (
//                   <div className="w-full h-48 bg-gray-200 flex items-center justify-center">
//                     <span className="text-gray-500">No Image</span>
//                   </div>
//                 )}
//                 <div className="p-4">
//                   <h3 className="text-lg font-semibold text-gray-900">
//                     {product.name}
//                   </h3>
//                   <p className="mt-1 text-sm text-gray-600">
//                     {product.category || 'No category'}
//                   </p>
//                   <p className="mt-1 text-lg font-medium text-orange-600">
//                     ${product.price.toFixed(2)}
//                   </p>
//                   <button
//                     className="mt-4 w-full bg-green-500 text-white py-2 px-4 rounded-md hover:bg-green-600 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-orange-600"
//                     onClick={() => alert('Purchase functionality coming soon!')}
//                   >
//                     Buy Now
//                   </button>
//                 </div>
//               </div>
//             ))}
//           </div>
//         )}
//       </div>
//     </div>
//   );
// };

// export default ProductListing;


import { useState, useEffect } from 'react';
import { useParams, Link, useNavigate } from 'react-router-dom';
import axios from 'axios';

function ProductListing() {
  const { id } = useParams(); // Get businessId from URL
  const [products, setProducts] = useState([]);
  const [business, setBusiness] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  const navigate = useNavigate();

  useEffect(() => {
    const fetchData = async () => {
      setLoading(true);
      setError('');
      try {
        // Fetch business details
        const businessResponse = await axios.get(`http://localhost:3000/businesses/${id}`);
        setBusiness(businessResponse.data);
        // Fetch products for the business
        const productsResponse = await axios.get(`http://localhost:3000/businesses/${id}/products`);
        setProducts(productsResponse.data);
      } catch (error) {
        setError(error.response?.data?.error || 'Failed to load data. Please try again.');
      } finally {
        setLoading(false);
      }
    };
    fetchData();
  }, [id]);

  // Clear messages after 3 seconds
  useEffect(() => {
    if (error || success) {
      const timer = setTimeout(() => {
        setError('');
        setSuccess('');
      }, 3000);
      return () => clearTimeout(timer);
    }
  }, [error, success]);

  // Navigate to product details
  const handleBuyNow = (productId) => {
    navigate(`/products/${productId}`);
  };

  return (
    <div className="min-h-screen bg-gray-100 py-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <Link
            to="/businesses"
            className="inline-flex items-center text-sm font-medium text-orange-600 hover:underline"
          >
            <svg
              className="w-5 h-5 mr-2"
              fill="none"
              stroke="currentColor"
              viewBox="0 0 24 24"
              xmlns="http://www.w3.org/2000/svg"
            >
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth="2"
                d="M15 19l-7-7 7-7"
              />
            </svg>
            Back to Businesses
          </Link>
          <h1 className="mt-4 text-3xl font-extrabold text-green-800">
            {business ? `${business.name} - Products` : 'Loading Business...'}
          </h1>
          {business && (
            <p className="mt-2 text-sm text-gray-600">Location: {business.location}</p>
          )}
        </div>

        {/* Messages */}
        {error && (
          <div className="mb-6 p-4 bg-red-100 text-red-700 rounded-lg text-center">
            {error}
          </div>
        )}
        {success && (
          <div className="mb-6 p-4 bg-green-100 text-green-700 rounded-lg text-center">
            {success}
          </div>
        )}

        {/* Loading State */}
        {loading && (
          <div className="text-center text-gray-600 text-lg">Loading products...</div>
        )}

        {/* Products Grid */}
        {!loading && !error && products.length === 0 && (
          <div className="text-center text-gray-600 text-lg">
            No products available for this business.
          </div>
        )}
        {!loading && !error && products.length > 0 && (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {products.map((product) => (
              <div
                key={product.id}
                className="bg-white border border-gray-200 rounded-lg shadow-md overflow-hidden hover:shadow-lg transition"
              >
                {product.image ? (
                  <img
                    src={`http://localhost:3000${product.image}`}
                    alt={product.name}
                    className="w-full h-48 object-cover"
                  />
                ) : (
                  <div className="w-full h-48 bg-gray-200 flex items-center justify-center">
                    <span className="text-gray-500">No Image</span>
                  </div>
                )}
                <div className="p-6">
                  <h3 className="text-lg font-semibold text-green-800">{product.name}</h3>
                  <p className="mt-1 text-lg font-medium text-orange-600">${product?.price?.toFixed(2)}</p>
                  <button
                    onClick={() => handleBuyNow(product.id)}
                    className="mt-4 w-full bg-green-500 text-white py-2 px-4 rounded-lg hover:bg-green-600 transition"
                  >
                    Buy Now
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

export default ProductListing;