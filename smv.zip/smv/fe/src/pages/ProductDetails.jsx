// import { useState, useEffect } from 'react';
// import { useParams, Link, useNavigate } from 'react-router-dom';
// import axios from 'axios';

// function ProductDetails() {
//   const { id } = useParams(); // Get productId from URL
//   const [product, setProduct] = useState(null);
//   const [business, setBusiness] = useState(null);
//   const [quantity, setQuantity] = useState(1);
//   const [loading, setLoading] = useState(true);
//   const [error, setError] = useState('');
//   const [success, setSuccess] = useState('');
//   const navigate = useNavigate();

//   useEffect(() => {
//     const fetchData = async () => {
//         const token = localStorage.getItem('token');
//     if (!token) {
//       navigate('/login');
//       return;
//     }
//       setLoading(true);
//       setError('');
//       try {
//         // Fetch product details
//         const productResponse = await axios.get(`http://localhost:3000/products/${id}`,{
//             headers: {
//               'Content-Type': 'application/json',
//               Authorization: `Bearer ${token}`,
//             },
//           });
//         const productData = productResponse.data;
//         setProduct(productData);
//         // Fetch business details
//         const businessResponse = await axios.get(`http://localhost:3000/businesses/${productData.businessId}`);
//         setBusiness(businessResponse.data);
//       } catch (error) {
//         setError(error.response?.data?.error || 'Failed to load product details.');
//       } finally {
//         setLoading(false);
//       }
//     };
//     fetchData();
//   }, [id]);

//   // Clear messages after 3 seconds
//   useEffect(() => {
//     if (error || success) {
//       const timer = setTimeout(() => {
//         setError('');
//         setSuccess('');
//       }, 3000);
//       return () => clearTimeout(timer);
//     }
//   }, [error, success]);

//   // Handle purchase
//   const handlePurchase = async () => {
//     const token = localStorage.getItem('token');
//     if (!token) {
//       navigate('/login');
//       return;
//     }
//     try {
//       const response = await axios.post(
//         'http://localhost:3000/purchases',
//         { productId: parseInt(id), quantity: parseInt(quantity) },
//         {
//           headers: {
//             'Content-Type': 'application/json',
//             Authorization: `Bearer ${token}`,
//           },
//         }
//       );
//       setSuccess('Purchase successful!');
//       setQuantity(1);
//     } catch (error) {
//       setError(error.response?.data?.error || 'Failed to complete purchase.');
//     }
//   };

//   return (
//     <div className="min-h-screen bg-gray-100 py-12 px-4 sm:px-6 lg:px-8">
//       <div className="max-w-4xl mx-auto bg-white rounded-lg shadow-xl overflow-hidden">
//         {/* Header */}
//         <div className="p-6 border-b border-gray-200">
//           <Link
//             to={`/businesses/${business?.id}/products`}
//             className="inline-flex items-center text-sm font-medium text-orange-600 hover:underline"
//           >
//             <svg
//               className="w-5 h-5 mr-2"
//               fill="none"
//               stroke="currentColor"
//               viewBox="0 0 24 24"
//               xmlns="http://www.w3.org/2000/svg"
//             >
//               <path
//                 strokeLinecap="round"
//                 strokeLinejoin="round"
//                 strokeWidth="2"
//                 d="M15 19l-7-7 7-7"
//               />
//             </svg>
//             Back to Products
//           </Link>
//           <h1 className="mt-4 text-3xl font-extrabold text-green-800">
//             {product ? product.name : 'Loading Product...'}
//           </h1>
//         </div>

//         {/* Messages */}
//         {error && (
//           <div className="m-6 p-4 bg-red-100 text-red-700 rounded-lg">
//             {error}
//           </div>
//         )}
//         {success && (
//           <div className="m-6 p-4 bg-green-100 text-green-700 rounded-lg">
//             {success}
//           </div>
//         )}

//         {/* Loading State */}
//         {loading && (
//           <div className="p-6 text-center text-gray-600 text-lg">Loading product details...</div>
//         )}

//         {/* Product Details */}
//         {!loading && !error && product && (
//           <div className="flex flex-col md:flex-row">
//             <div className="md:w-1/2 p-6">
//               {product.image ? (
//                 <img
//                   src={`http://localhost:3000${product.image}`}
//                   alt={product.name}
//                   className="w-full h-96 object-cover rounded-lg"
//                 />
//               ) : (
//                 <div className="w-full h-96 bg-gray-200 flex items-center justify-center rounded-lg">
//                   <span className="text-gray-500">No Image</span>
//                 </div>
//               )}
//             </div>
//             <div className="md:w-1/2 p-6">
//               <h2 className="text-2xl font-semibold text-green-800">{product.name}</h2>
//               <p className="mt-2 text-lg font-medium text-orange-600">${product.price.toFixed(2)}</p>
//               <p className="mt-4 text-gray-600">
//                 Sold by: {business ? business.name : 'Loading...'}
//               </p>
//               <p className="mt-2 text-gray-600">
//                 Location: {business ? business.location : 'Loading...'}
//               </p>
//               <div className="mt-6">
//                 <label className="block text-sm font-medium text-gray-700">Quantity</label>
//                 <input
//                   type="number"
//                   value={quantity}
//                   onChange={(e) => setQuantity(Math.max(1, parseInt(e.target.value) || 1))}
//                   className="mt-1 w-24 p-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-400 focus:outline-none"
//                   min="1"
//                 />
//               </div>
//               <button
//                 onClick={handlePurchase}
//                 className="mt-6 w-full bg-green-500 text-white py-3 px-4 rounded-lg hover:bg-green-600 transition"
//               >
//                 Purchase
//               </button>
//             </div>
//           </div>
//         )}
//       </div>
//     </div>
//   );
// }

// export default ProductDetails;


import { useState, useEffect } from 'react';
import { useParams, Link, useNavigate } from 'react-router-dom';
import axios from 'axios';

function ProductDetails() {
  const { id } = useParams();
  const [product, setProduct] = useState(null);
  const [business, setBusiness] = useState(null);
  const [quantity, setQuantity] = useState(1);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  const navigate = useNavigate();

  useEffect(() => {
    const fetchData = async () => {
      const token = localStorage.getItem('token');
      if (!token) {
        navigate('/login');
        return;
      }
      setLoading(true);
      setError('');
      try {
        const productResponse = await axios.get(`http://localhost:3000/products/${id}`, {
          headers: { Authorization: `Bearer ${token}` },
        });
        const productData = productResponse.data;
        setProduct(productData);
        const businessResponse = await axios.get(`http://localhost:3000/businesses/${productData.businessId}`);
        setBusiness(businessResponse.data);
      } catch (error) {
        setError(error.response?.data?.error || 'Failed to load product details.');
      } finally {
        setLoading(false);
      }
    };
    fetchData();
  }, [id, navigate]);

  useEffect(() => {
    if (error || success) {
      const timer = setTimeout(() => {
        setError('');
        setSuccess('');
      }, 3000);
      return () => clearTimeout(timer);
    }
  }, [error, success]);

  const handlePurchase = async () => {
    const token = localStorage.getItem('token');
    if (!token) {
      navigate('/login');
      return;
    }
    try {
      const response = await axios.post(
        'http://localhost:3000/purchases',
        { productId: parseInt(id), quantity: parseInt(quantity) },
        { headers: { Authorization: `Bearer ${token}` } }
      );
      setSuccess('Purchase successful!');
      setQuantity(1);
    } catch (error) {
      setError(error.response?.data?.error || 'Failed to complete purchase.');
    }
  };

  const handleAddToCart = () => {
    setSuccess('Added to cart! (Placeholder)');
    // Future: Implement cart functionality
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-green-50 to-orange-50 py-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-5xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <Link
            to={`/businesses/${business?.id}/products`}
            className="inline-flex items-center text-sm font-medium text-orange-600 hover:underline transition"
          >
            <svg className="w-5 h-5 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M15 19l-7-7 7-7" />
            </svg>
            Back to Products
          </Link>
        </div>

        {/* Messages */}
        {(error || success) && (
          <div className={`mb-6 p-4 rounded-lg text-center animate-fade-in-up ${error ? 'bg-red-100 text-red-700' : 'bg-green-100 text-green-700'}`}>
            {error || success}
          </div>
        )}

        {/* Loading State */}
        {loading && (
          <div className="text-center text-gray-600 text-lg animate-pulse">Loading product details...</div>
        )}

        {/* Product Details */}
        {!loading && !error && product && (
          <div className="bg-white rounded-lg shadow-xl overflow-hidden">
            <div className="flex flex-col md:flex-row">
              <div className="md:w-1/2 p-8">
                {product.image ? (
                  <img
                    src={`http://localhost:3000${product.image}`}
                    alt={product.name}
                    className="w-full h-96 object-cover rounded-lg shadow-md transition transform hover:scale-105"
                  />
                ) : (
                  <div className="w-full h-96 bg-gray-200 flex items-center justify-center rounded-lg">
                    <span className="text-gray-500">No Image</span>
                  </div>
                )}
              </div>
              <div className="md:w-1/2 p-8 flex flex-col justify-between">
                <div>
                  <h1 className="text-3xl font-extrabold text-green-800">{product.name}</h1>
                  <p className="mt-2 text-2xl font-semibold text-orange-600">${product?.price?.toFixed(2)}</p>
                  <p className="mt-4 text-gray-600">Sold by: <span className="font-medium">{business?.name || 'Loading...'}</span></p>
                  <p className="mt-2 text-gray-600">Location: <span className="font-medium">{business?.location || 'Loading...'}</span></p>
                  <div className="mt-6">
                    <label htmlFor="quantity" className="block text-sm font-medium text-gray-700">Quantity</label>
                    <input
                      id="quantity"
                      type="number"
                      value={quantity}
                      onChange={(e) => setQuantity(Math.max(1, parseInt(e.target.value) || 1))}
                      className="mt-1 w-24 p-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-400 focus:outline-none"
                      min="1"
                      aria-required="true"
                    />
                  </div>
                </div>
                <div className="mt-8 space-y-4">
                  <button
                    onClick={handlePurchase}
                    className="w-full py-3 bg-green-500 text-white rounded-lg hover:bg-green-600 transition transform hover:scale-105"
                  >
                    Purchase Now
                  </button>
                  <button
                    onClick={handleAddToCart}
                    className="w-full py-3 bg-orange-500 text-white rounded-lg hover:bg-orange-600 transition transform hover:scale-105"
                  >
                    Add to Cart
                  </button>
                </div>
              </div>
            </div>
            {/* Review Placeholder */}
            <div className="p-8 border-t border-gray-200">
              <h2 className="text-xl font-semibold text-green-800">Customer Reviews</h2>
              <p className="mt-2 text-gray-600">No reviews yet. Be the first to share your experience!</p>
              {/* Future: Add review form and list */}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

export default ProductDetails;