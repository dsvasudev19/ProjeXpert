// import { useState, useEffect } from 'react';

// function AdminDashboard() {
//   const [businesses, setBusinesses] = useState([]);
//   const [name, setName] = useState('');
//   const [location, setLocation] = useState('');

//   // Fetch all businesses
//   useEffect(() => {
//     const fetchBusinesses = async () => {
//       try {
//         const token = localStorage.getItem('token');
//         const response = await fetch('http://localhost:3000/businesses', {
//           headers: {
//             'Content-Type': 'application/json',
//             Authorization: `Bearer ${token}`,
//           },
//         });
//         const data = await response.json();
//         if (response.ok) {
//           setBusinesses(data);
//         } else {
//           alert(data.error || 'Failed to fetch businesses');
//         }
//       } catch (error) {
//         alert('Error: ' + error.message);
//       }
//     };
//     fetchBusinesses();
//   }, []);

//   // Handle business creation
//   const handleCreateBusiness = async () => {
//     try {
//       const token = localStorage.getItem('token');
//       const response = await fetch('http://localhost:3000/businesses', {
//         method: 'POST',
//         headers: {
//           'Content-Type': 'application/json',
//           Authorization: `Bearer ${token}`,
//         },
//         body: JSON.stringify({ name, location }),
//       });
//       const data = await response.json();
//       if (response.ok) {
//         alert('Business created successfully!');
//         setBusinesses([...businesses, data]);
//         setName('');
//         setLocation('');
//       } else {
//         alert(data.error || 'Failed to create business');
//       }
//     } catch (error) {
//       alert('Error: ' + error.message);
//     }
//   };

//   return (
//     <div className="w-full max-w-4xl bg-white p-8 rounded-lg shadow-lg">
//       <h2 className="text-2xl font-bold text-center text-green-800 mb-6">Admin Dashboard</h2>
//       {/* Create Business Form */}
//       <div className="mb-8 p-4 border border-gray-300 rounded-lg">
//         <h3 className="text-lg font-semibold text-green-800 mb-4">Add New Business</h3>
//         <div className="space-y-4">
//           <div>
//             <label className="block text-sm font-medium text-gray-700">Business Name</label>
//             <input
//               type="text"
//               value={name}
//               onChange={(e) => setName(e.target.value)}
//               className="mt-1 w-full p-2 border border-gray-300 rounded focus:ring-2 focus:ring-orange-400"
//               placeholder="Enter business name"
//             />
//           </div>
//           <div>
//             <label className="block text-sm font-medium text-gray-700">Location</label>
//             <input
//               type="text"
//               value={location}
//               onChange={(e) => setLocation(e.target.value)}
//               className="mt-1 w-full p-2 border border-gray-300 rounded focus:ring-2 focus:ring-orange-400"
//               placeholder="Enter location"
//             />
//           </div>
//           <button
//             onClick={handleCreateBusiness}
//             className="w-full py-2 bg-orange-500 text-white rounded hover:bg-orange-600 transition"
//             disabled={!name || !location}
//           >
//             Add Business
//           </button>
//         </div>
//       </div>
//       {/* Business List */}
//       <h3 className="text-lg font-semibold text-green-800 mb-4">All Businesses</h3>
//       {businesses.length === 0 ? (
//         <p className="text-center text-gray-600">No businesses found.</p>
//       ) : (
//         <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
//           {businesses.map((business) => (
//             <div key={business.id} className="p-4 border border-gray-300 rounded-lg">
//               <h4 className="text-md font-medium text-green-800">{business.name}</h4>
//               <p className="text-sm text-gray-600">Location: {business.location}</p>
//               <p className="text-sm text-gray-600">Owner ID: {business.userId || 'Admin Created'}</p>
//             </div>
//           ))}
//         </div>
//       )}
//     </div>
//   );
// }

// export default AdminDashboard;
import { useState, useEffect } from 'react';

function AdminDashboard() {
  const [businesses, setBusinesses] = useState([]);
  const [users, setUsers] = useState([]);
  const [name, setName] = useState('');
  const [location, setLocation] = useState('');
  const [userId, setUserId] = useState('');
  const [image, setImage] = useState(null);
  const [editingBusiness, setEditingBusiness] = useState(null);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');

  // Fetch all businesses and users
  useEffect(() => {
    const fetchBusinesses = async () => {
      try {
        const token = localStorage.getItem('token');
        const response = await fetch('http://localhost:3000/businesses', {
          headers: {
            'Content-Type': 'application/json',
            Authorization: `Bearer ${token}`,
          },
        });
        const data = await response.json();
        if (response.ok) {
          setBusinesses(data);
        } else {
          setError(data.error || 'Failed to fetch businesses');
        }
      } catch (error) {
        setError('Error: ' + error.message);
      }
    };

    const fetchUsers = async () => {
      try {
        const token = localStorage.getItem('token');
        const response = await fetch('http://localhost:3000/users', {
          headers: {
            'Content-Type': 'application/json',
            Authorization: `Bearer ${token}`,
          },
        });
        const data = await response.json();
        if (response.ok) {
          setUsers(data);
        } else {
          setError(data.error || 'Failed to fetch users');
        }
      } catch (error) {
        setError('Error: ' + error.message);
      }
    };

    fetchBusinesses();
    fetchUsers();
  }, []);

  // Clear messages after 3 seconds
  useEffect(() => {
    if (error || success) {
      const timer = setTimeout(() => {
        setError('');
        setSuccess('');
      }, 3000);
      return () => clearTimeout(timer);
    }
  }, [error, success]);

  // Handle business creation
  const handleCreateBusiness = async (e) => {
    e.preventDefault();
    try {
      const token = localStorage.getItem('token');
      const formData = new FormData();
      formData.append('name', name);
      formData.append('location', location);
      formData.append('userId', userId); // Required for admins
      if (image) formData.append('image', image);

      const response = await fetch('http://localhost:3000/businesses', {
        method: 'POST',
        headers: {
          Authorization: `Bearer ${token}`,
        },
        body: formData,
      });
      const data = await response.json();
      if (response.ok) {
        setSuccess('Business created successfully!');
        setBusinesses([...businesses, data]);
        setName('');
        setLocation('');
        setUserId('');
        setImage(null);
      } else {
        setError(data.error || 'Failed to create business');
      }
    } catch (error) {
      setError('Error: ' + error.message);
    }
  };

  // Handle business update
  const handleUpdateBusiness = async (e) => {
    e.preventDefault();
    try {
      const token = localStorage.getItem('token');
      const formData = new FormData();
      if (name) formData.append('name', name);
      if (location) formData.append('location', location);
      if (image) formData.append('image', image);

      const response = await fetch(`http://localhost:3000/businesses/${editingBusiness.id}`, {
        method: 'PUT',
        headers: {
          Authorization: `Bearer ${token}`,
        },
        body: formData,
      });
      const data = await response.json();
      if (response.ok) {
        setSuccess('Business updated successfully!');
        setBusinesses(businesses.map((b) => (b.id === editingBusiness.id ? data : b)));
        setEditingBusiness(null);
        setName('');
        setLocation('');
        setImage(null);
      } else {
        setError(data.error || 'Failed to update business');
      }
    } catch (error) {
      setError('Error: ' + error.message);
    }
  };

  // Handle business deletion
  const handleDeleteBusiness = async (id) => {
    if (!window.confirm('Are you sure you want to delete this business?')) return;
    try {
      const token = localStorage.getItem('token');
      const response = await fetch(`http://localhost:3000/businesses/${id}`, {
        method: 'DELETE',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
      });
      const data = await response.json();
      if (response.ok) {
        setSuccess('Business deleted successfully!');
        setBusinesses(businesses.filter((b) => b.id !== id));
      } else {
        setError(data.error || 'Failed to delete business');
      }
    } catch (error) {
      setError('Error: ' + error.message);
    }
  };

  // Start editing a business
  const startEditing = (business) => {
    setEditingBusiness(business);
    setName(business.name);
    setLocation(business.location);
    setImage(null);
  };

  // Cancel editing
  const cancelEditing = () => {
    setEditingBusiness(null);
    setName('');
    setLocation('');
    setImage(null);
  };

  return (
    <div className="min-h-screen bg-gray-100 flex items-center justify-center p-4">
      <div className="w-full max-w-5xl bg-white p-8 rounded-lg shadow-xl">
        <h2 className="text-3xl font-bold text-center text-green-800 mb-8">Admin Dashboard</h2>

        {/* Messages */}
        {error && (
          <div className="mb-4 p-4 bg-red-100 text-red-700 rounded-lg">
            {error}
          </div>
        )}
        {success && (
          <div className="mb-4 p-4 bg-green-100 text-green-700 rounded-lg">
            {success}
          </div>
        )}

        {/* Business Form */}
        <div className="mb-12 p-6 border border-gray-200 rounded-lg bg-gray-50">
          <h3 className="text-xl font-semibold text-green-800 mb-6">
            {editingBusiness ? 'Edit Business' : 'Add New Business'}
          </h3>
          <form onSubmit={editingBusiness ? handleUpdateBusiness : handleCreateBusiness} className="space-y-6">
            <div>
              <label className="block text-sm font-medium text-gray-700">Business Name</label>
              <input
                type="text"
                value={name}
                onChange={(e) => setName(e.target.value)}
                className="mt-1 w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-400 focus:outline-none"
                placeholder="Enter business name"
                required
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700">Location</label>
              <input
                type="text"
                value={location}
                onChange={(e) => setLocation(e.target.value)}
                className="mt-1 w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-400 focus:outline-none"
                placeholder="Enter location"
                required
              />
            </div>
            {!editingBusiness && (
              <div>
                <label className="block text-sm font-medium text-gray-700">Business Owner</label>
                <select
                  value={userId}
                  onChange={(e) => setUserId(e.target.value)}
                  className="mt-1 w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-400 focus:outline-none"
                  required
                >
                  <option value="" disabled>Select a user</option>
                  {users.map((user) => (
                    <option key={user.id} value={user.id}>
                      {user.username} ({user.role})
                    </option>
                  ))}
                </select>
              </div>
            )}
            <div>
              <label className="block text-sm font-medium text-gray-700">Business Image</label>
              <input
                type="file"
                accept="image/jpeg,image/png"
                onChange={(e) => setImage(e.target.files[0])}
                className="mt-1 w-full p-3 border border-gray-300 rounded-lg file:mr-4 file:py-2 file:px-4 file:rounded-lg file:border-0 file:bg-orange-500 file:text-white hover:file:bg-orange-600"
              />
            </div>
            <div className="flex space-x-4">
              <button
                type="submit"
                className="flex-1 py-3 bg-orange-500 text-white rounded-lg hover:bg-orange-600 transition disabled:bg-orange-300"
                disabled={!name || !location || (!editingBusiness && !userId)}
              >
                {editingBusiness ? 'Update Business' : 'Add Business'}
              </button>
              {editingBusiness && (
                <button
                  type="button"
                  onClick={cancelEditing}
                  className="flex-1 py-3 bg-gray-500 text-white rounded-lg hover:bg-gray-600 transition"
                >
                  Cancel
                </button>
              )}
            </div>
          </form>
        </div>

        {/* Business List */}
        <h3 className="text-xl font-semibold text-green-800 mb-6">All Businesses</h3>
        {businesses.length === 0 ? (
          <p className="text-center text-gray-600">No businesses found.</p>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {businesses.map((business) => (
              <div key={business.id} className="p-6 border border-gray-200 rounded-lg bg-white hover:shadow-lg transition">
                {business.image && (
                  <img
                    src={`http://localhost:3000${business.image}`}
                    alt={business.name}
                    className="w-full h-40 object-cover rounded-lg mb-4"
                  />
                )}
                <h4 className="text-lg font-medium text-green-800">{business.name}</h4>
                <p className="text-sm text-gray-600">Location: {business.location}</p>
                <p className="text-sm text-gray-600">Owner ID: {business.userId || 'Admin Created'}</p>
                <div className="mt-4 flex space-x-4">
                  <button
                    onClick={() => startEditing(business)}
                    className="flex-1 py-2 bg-blue-500 text-white rounded-lg hover:bg-blue-600 transition"
                  >
                    Edit
                  </button>
                  <button
                    onClick={() => handleDeleteBusiness(business.id)}
                    className="flex-1 py-2 bg-red-500 text-white rounded-lg hover:bg-red-600 transition"
                  >
                    Delete
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

export default AdminDashboard;