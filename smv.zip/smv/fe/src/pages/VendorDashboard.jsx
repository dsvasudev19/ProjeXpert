import { Link } from 'react-router-dom';

function VendorDashboard() {
  return (
    <div className="min-h-screen flex items-center justify-center bg-gray-100 p-4">
      <div className="w-full max-w-4xl bg-white p-8 rounded-lg shadow-lg">
        <h2 className="text-3xl font-bold text-center text-green-800 mb-8">Vendor Dashboard</h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
          <Link
            to="/vendor/products"
            className="p-6 bg-orange-500 text-white text-center rounded-lg hover:bg-orange-600 transition text-lg font-medium"
          >
            Manage Products
          </Link>
          <Link
            to="/vendor/orders"
            className="p-6 bg-orange-500 text-white text-center rounded-lg hover:bg-orange-600 transition text-lg font-medium"
          >
            Manage Orders
          </Link>
        </div>
      </div>
    </div>
  );
}

export default VendorDashboard;
