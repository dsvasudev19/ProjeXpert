// import { useState, useEffect } from 'react';
// import { useNavigate } from 'react-router-dom';

// function BusinessList() {
//   const [businesses, setBusinesses] = useState([]);
//   const navigate = useNavigate();

//   // Fetch businesses on component mount
//   useEffect(() => {
//     const fetchBusinesses = async () => {
//       try {
//         const response = await fetch('http://localhost:3000/businesses', {
//           headers: { 'Content-Type': 'application/json' },
//         });
//         const data = await response.json();
//         if (response.ok) {
//           setBusinesses(data);
//         } else {
//           alert(data.error || 'Failed to fetch businesses');
//         }
//       } catch (error) {
//         alert('Error: ' + error.message);
//       }
//     };
//     fetchBusinesses();
//   }, []);

//   // Navigate to products page for a business
//   const handleExplore = (businessId) => {
//     navigate(`/businesses/${businessId}/products`);
//   };

//   return (
//     <div className="w-full max-w-4xl bg-white p-8 rounded-lg shadow-lg">
//       <h2 className="text-2xl font-bold text-center text-green-800 mb-6">Explore Local Businesses</h2>
//       {businesses.length === 0 ? (
//         <p className="text-center text-gray-600">No businesses found.</p>
//       ) : (
//         <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
//           {businesses.map((business) => (
//             <div key={business.id} className="p-4 border border-gray-300 rounded-lg">
//               <h3 className="text-lg font-semibold text-green-800">{business.name}</h3>
//               <p className="text-sm text-gray-600">Location: {business.location}</p>
//               <button
//                 onClick={() => handleExplore(business.id)}
//                 className="mt-2 py-1 px-4 bg-orange-500 text-white rounded hover:bg-orange-600 transition"
//               >
//                 Explore
//               </button>
//             </div>
//           ))}
//         </div>
//       )}
//     </div>
//   );
// }

// export default BusinessList;

import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';

function BusinessList() {
  const [businesses, setBusinesses] = useState([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  const navigate = useNavigate();

  // Fetch businesses on component mount or search
  useEffect(() => {
    const fetchBusinesses = async () => {
      try {
        const url = searchTerm
          ? `http://localhost:3000/businesses/search?location=${encodeURIComponent(searchTerm)}`
          : 'http://localhost:3000/businesses';
        const response = await axios.get(url);
        setBusinesses(response.data);
        if (searchTerm && response.data.length === 0) {
          setError('No businesses found for this location.');
        }
      } catch (error) {
        setError(error.response?.data?.error || 'Failed to fetch businesses.');
      }
    };
    fetchBusinesses();
  }, [searchTerm]);

  // Clear messages after 3 seconds
  useEffect(() => {
    if (error || success) {
      const timer = setTimeout(() => {
        setError('');
        setSuccess('');
      }, 3000);
      return () => clearTimeout(timer);
    }
  }, [error, success]);

  // Handle search input change
  const handleSearch = (e) => {
    setSearchTerm(e.target.value);
  };

  // Navigate to products page for a business
  const handleExplore = (businessId) => {
    navigate(`/businesses/${businessId}/products`);
  };

  return (
    <div className="min-h-screen bg-gray-100 flex flex-col items-center py-12 px-4 sm:px-6 lg:px-8">
      <div className="w-full max-w-7xl">
        <h2 className="text-4xl font-extrabold text-center text-green-800 mb-8">Explore Local Businesses</h2>

        {/* Search Bar */}
        <div className="mb-8 flex justify-center">
          <input
            type="text"
            value={searchTerm}
            onChange={handleSearch}
            placeholder="Search businesses by location..."
            className="w-full max-w-md p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-400 focus:outline-none"
          />
        </div>

        {/* Messages */}
        {error && (
          <div className="mb-6 p-4 bg-red-100 text-red-700 rounded-lg text-center">
            {error}
          </div>
        )}
        {success && (
          <div className="mb-6 p-4 bg-green-100 text-green-700 rounded-lg text-center">
            {success}
          </div>
        )}

        {/* Business List */}
        {businesses.length === 0 && !error ? (
          <p className="text-center text-gray-600 text-lg">No businesses found.</p>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {businesses.map((business) => (
              <div
                key={business.id}
                className="bg-white border border-gray-200 rounded-lg shadow-md overflow-hidden hover:shadow-lg transition"
              >
                {business.image ? (
                  <img
                    src={`http://localhost:3000${business.image}`}
                    alt={business.name}
                    className="w-full h-48 object-cover"
                  />
                ) : (
                  <div className="w-full h-48 bg-gray-200 flex items-center justify-center">
                    <span className="text-gray-500">No Image</span>
                  </div>
                )}
                <div className="p-6">
                  <h3 className="text-xl font-semibold text-green-800">{business.name}</h3>
                  <p className="text-sm text-gray-600 mt-1">Location: {business.location}</p>
                  <button
                    onClick={() => handleExplore(business.id)}
                    className="mt-4 w-full bg-orange-500 text-white py-2 px-4 rounded-lg hover:bg-orange-600 transition"
                  >
                    Explore Products
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

export default BusinessList;