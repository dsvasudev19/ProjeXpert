// import { useState, useEffect } from 'react';
// import { useNavigate } from 'react-router-dom';

// function ProductManagement() {
//   const [businesses, setBusinesses] = useState([]);
//   const [products, setProducts] = useState([]);
//   const [name, setName] = useState('');
//   const [price, setPrice] = useState('');
//   const [businessId, setBusinessId] = useState('');
//   const navigate = useNavigate();

//   // Fetch vendor's businesses and products
//   useEffect(() => {
//     const fetchData = async () => {
//       try {
//         const token = localStorage.getItem('token');
//         // Fetch businesses
//         const businessResponse = await fetch('http://localhost:3000/businesses', {
//           headers: {
//             'Content-Type': 'application/json',
//             Authorization: `Bearer ${token}`,
//           },
//         });
//         const businessData = await businessResponse.json();
//         if (businessResponse.ok) {
//           console.log(businessData)
//           setBusinesses(businessData);
//         }

//         // Fetch products for all businesses (simplified, could be optimized)
//         const productPromises = businessData.map(async (business) => {
//           const response = await fetch(`http://localhost:3000/businesses/${business.id}/products`, {
//             headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
//           });
//           const data = await response.json();
//           return response.ok ? data.map((p) => ({ ...p, businessName: business.name })) : [];
//         });
//         const productsData = await Promise.all(productPromises);
//         setProducts(productsData.flat());
//       } catch (error) {
//         alert('Error: ' + error.message);
//       }
//     };
//     fetchData();
//   }, []);

//   // Handle product creation
//   const handleCreateProduct = async () => {
//     try {
//       const token = localStorage.getItem('token');
//       const response = await fetch('http://localhost:3000/products', {
//         method: 'POST',
//         headers: {
//           'Content-Type': 'application/json',
//           Authorization: `Bearer ${token}`,
//         },
//         body: JSON.stringify({ name, price: parseFloat(price), businessId: parseInt(businessId) }),
//       });
//       const data = await response.json();
//       if (response.ok) {
//         alert('Product created successfully!');
//         setProducts([...products, { ...data, businessName: businesses.find((b) => b.id === parseInt(businessId)).name }]);
//         setName('');
//         setPrice('');
//         setBusinessId('');
//       } else {
//         alert(data.error || 'Failed to create product');
//       }
//     } catch (error) {
//       alert('Error: ' + error.message);
//     }
//   };

//   return (
//     <div className="w-full max-w-4xl bg-white p-8 rounded-lg shadow-lg">
//       <h2 className="text-2xl font-bold text-center text-green-800 mb-6">Manage Products</h2>
//       {/* Create Product Form */}
//       <div className="mb-8 p-4 border border-gray-300 rounded-lg">
//         <h3 className="text-lg font-semibold text-green-800 mb-4">Add New Product</h3>
//         <div className="space-y-4">
//           <div>
//             <label className="block text-sm font-medium text-gray-700">Product Name</label>
//             <input
//               type="text"
//               value={name}
//               onChange={(e) => setName(e.target.value)}
//               className="mt-1 w-full p-2 border border-gray-300 rounded focus:ring-2 focus:ring-orange-400"
//               placeholder="Enter product name"
//             />
//           </div>
//           <div>
//             <label className="block text-sm font-medium text-gray-700">Price</label>
//             <input
//               type="number"
//               value={price}
//               onChange={(e) => setPrice(e.target.value)}
//               className="mt-1 w-full p-2 border border-gray-300 rounded focus:ring-2 focus:ring-orange-400"
//               placeholder="Enter price"
//             />
//           </div>
//           <div>
//             <label className="block text-sm font-medium text-gray-700">Business</label>
//             <select
//               value={businessId}
//               onChange={(e) => setBusinessId(e.target.value)}
//               className="mt-1 w-full p-2 border border-gray-300 rounded focus:ring-2 focus:ring-orange-400"
//             >
//               <option value="">Select a business</option>
//               {businesses.map((business) => (
//                 <option key={business.id} value={business.id}>
//                   {business.name}
//                 </option>
//               ))}
//             </select>
//           </div>
//           <button
//             onClick={handleCreateProduct}
//             className="w-full py-2 bg-orange-500 text-white rounded hover:bg-orange-600 transition"
//             disabled={!name || !price || !businessId}
//           >
//             Add Product
//           </button>
//         </div>
//       </div>
//       {/* Product List */}
//       <h3 className="text-lg font-semibold text-green-800 mb-4">Your Products</h3>
//       {products.length === 0 ? (
//         <p className="text-center text-gray-600">No products found.</p>
//       ) : (
//         <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
//           {products.map((product) => (
//             <div key={product.id} className="p-4 border border-gray-300 rounded-lg">
//               <h4 className="text-md font-medium text-green-800">{product.name}</h4>
//               <p className="text-sm text-gray-600">Price: ${product.price.toFixed(2)}</p>
//               <p className="text-sm text-gray-600">Business: {product.businessName}</p>
//             </div>
//           ))}
//         </div>
//       )}
//     </div>
//   );
// }

// export default ProductManagement;


import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';

function ProductManagement() {
  const [businesses, setBusinesses] = useState([]);
  const [products, setProducts] = useState([]);
  const [name, setName] = useState('');
  const [price, setPrice] = useState('');
  const [businessId, setBusinessId] = useState('');
  const [image, setImage] = useState(null);
  const [editingProduct, setEditingProduct] = useState(null);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  const navigate = useNavigate();

  // Fetch vendor's businesses and products
  useEffect(() => {
    const fetchData = async () => {
      try {
        const token = localStorage.getItem('token');
        if (!token) {
          navigate('/login');
          return;
        }

        // Fetch businesses
        const businessResponse = await fetch('http://localhost:3000/businesses', {
          headers: {
            'Content-Type': 'application/json',
            Authorization: `Bearer ${token}`,
          },
        });
        const businessData = await businessResponse.json();
        if (businessResponse.ok) {
          setBusinesses(businessData);
        } else {
          setError(businessData.error || 'Failed to fetch businesses');
        }

        // Fetch products for all businesses
        const productPromises = businessData.map(async (business) => {
          const response = await fetch(`http://localhost:3000/businesses/${business.id}/products`, {
            headers: { Authorization: `Bearer ${token}` },
          });
          const data = await response.json();
          return response.ok ? data.map((p) => ({ ...p, businessName: business.name })) : [];
        });
        const productsData = await Promise.all(productPromises);
        setProducts(productsData.flat());
      } catch (error) {
        setError('Error: ' + error.message);
      }
    };
    fetchData();
  }, [navigate]);

  // Clear messages after 3 seconds
  useEffect(() => {
    if (error || success) {
      const timer = setTimeout(() => {
        setError('');
        setSuccess('');
      }, 3000);
      return () => clearTimeout(timer);
    }
  }, [error, success]);

  // Handle product creation
  const handleCreateProduct = async (e) => {
    e.preventDefault();
    try {
      const token = localStorage.getItem('token');
      const formData = new FormData();
      formData.append('name', name);
      formData.append('price', parseFloat(price));
      formData.append('businessId', parseInt(businessId));
      if (image) formData.append('image', image);

      const response = await fetch('http://localhost:3000/products', {
        method: 'POST',
        headers: {
          Authorization: `Bearer ${token}`,
        },
        body: formData,
      });
      const data = await response.json();
      if (response.ok) {
        setSuccess('Product created successfully!');
        setProducts([...products, { ...data, businessName: businesses.find((b) => b.id === parseInt(businessId)).name }]);
        setName('');
        setPrice('');
        setBusinessId('');
        setImage(null);
      } else {
        setError(data.error || 'Failed to create product');
      }
    } catch (error) {
      setError('Error: ' + error.message);
    }
  };

  // Handle product update
  const handleUpdateProduct = async (e) => {
    e.preventDefault();
    try {
      const token = localStorage.getItem('token');
      const formData = new FormData();
      if (name) formData.append('name', name);
      if (price) formData.append('price', parseFloat(price));
      if (businessId) formData.append('businessId', parseInt(businessId));
      if (image) formData.append('image', image);

      const response = await fetch(`http://localhost:3000/products/${editingProduct.id}`, {
        method: 'PUT',
        headers: {
          Authorization: `Bearer ${token}`,
        },
        body: formData,
      });
      const data = await response.json();
      if (response.ok) {
        setSuccess('Product updated successfully!');
        
        setEditingProduct(null);
        setName('');
        setPrice('');
        setBusinessId('');
        setImage(null);
        fetchData(); // Refresh product list
      } else {
        setError(data.error || 'Failed to update product');
      }
    } catch (error) {
      setError('Error: ' + error.message);
    }
  };

  // Handle product deletion
  const handleDeleteProduct = async (id) => {
    if (!window.confirm('Are you sure you want to delete this product?')) return;
    try {
      const token = localStorage.getItem('token');
      const response = await fetch(`http://localhost:3000/products/${id}`, {
        method: 'DELETE',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
      });
      const data = await response.json();
      if (response.ok) {
        setSuccess('Product deleted successfully!');
        setProducts(products.filter((p) => p.id !== id));
      } else {
        setError(data.error || 'Failed to delete product');
      }
    } catch (error) {
      setError('Error: ' + error.message);
    }
  };

  // Start editing a product
  const startEditing = (product) => {
    setEditingProduct(product);
    setName(product.name);
    setPrice(product.price);
    setBusinessId(product.businessId);
    setImage(null);
  };

  // Cancel editing
  const cancelEditing = () => {
    setEditingProduct(null);
    setName('');
    setPrice('');
    setBusinessId('');
    setImage(null);
  };

  return (
    <div className="min-h-screen bg-gray-100 flex items-center justify-center p-4">
      <div className="w-full max-w-5xl bg-white p-8 rounded-lg shadow-xl">
        <h2 className="text-3xl font-bold text-center text-green-800 mb-8">Manage Products</h2>

        {/* Messages */}
        {error && (
          <div className="mb-4 p-4 bg-red-100 text-red-700 rounded-lg">
            {error}
          </div>
        )}
        {success && (
          <div className="mb-4 p-4 bg-green-100 text-green-700 rounded-lg">
            {success}
          </div>
        )}

        {/* Product Form */}
        <div className="mb-12 p-6 border border-gray-200 rounded-lg bg-gray-50">
          <h3 className="text-xl font-semibold text-green-800 mb-6">
            {editingProduct ? 'Edit Product' : 'Add New Product'}
          </h3>
          <form onSubmit={editingProduct ? handleUpdateProduct : handleCreateProduct} className="space-y-6">
            <div>
              <label className="block text-sm font-medium text-gray-700">Product Name</label>
              <input
                type="text"
                value={name}
                onChange={(e) => setName(e.target.value)}
                className="mt-1 w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-400 focus:outline-none"
                placeholder="Enter product name"
                required
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700">Price</label>
              <input
                type="number"
                value={price}
                onChange={(e) => setPrice(e.target.value)}
                className="mt-1 w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-400 focus:outline-none"
                placeholder="Enter price"
                step="0.01"
                min="0"
                required
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700">Business</label>
              <select
                value={businessId}
                onChange={(e) => setBusinessId(e.target.value)}
                className="mt-1 w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-400 focus:outline-none"
                required
              >
                <option value="" disabled>Select a business</option>
                {businesses.map((business) => (
                  <option key={business.id} value={business.id}>
                    {business.name}
                  </option>
                ))}
              </select>
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700">Product Image</label>
              <input
                type="file"
                accept="image/jpeg,image/png"
                onChange={(e) => setImage(e.target.files[0])}
                className="mt-1 w-full p-3 border border-gray-300 rounded-lg file:mr-4 file:py-2 file:px-4 file:rounded-lg file:border-0 file:bg-orange-500 file:text-white hover:file:bg-orange-600"
              />
            </div>
            <div className="flex space-x-4">
              <button
                type="submit"
                className="flex-1 py-3 bg-orange-500 text-white rounded-lg hover:bg-orange-600 transition disabled:bg-orange-300"
                disabled={!name || !price || !businessId}
              >
                {editingProduct ? 'Update Product' : 'Add Product'}
              </button>
              {editingProduct && (
                <button
                  type="button"
                  onClick={cancelEditing}
                  className="flex-1 py-3 bg-gray-500 text-white rounded-lg hover:bg-gray-600 transition"
                >
                  Cancel
                </button>
              )}
            </div>
          </form>
        </div>

        {/* Product List */}
        <h3 className="text-xl font-semibold text-green-800 mb-6">Your Products</h3>
        {products.length === 0 ? (
          <p className="text-center text-gray-600">No products found.</p>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {products.map((product) => (
              <div key={product.id} className="p-6 border border-gray-200 rounded-lg bg-white hover:shadow-lg transition">
                {product.image && (
                  <img
                    src={`http://localhost:3000${product.image}`}
                    alt={product.name}
                    className="w-full h-40 object-cover rounded-lg mb-4"
                  />
                )}
                <h4 className="text-lg font-medium text-green-800">{product.name}</h4>
                <p className="text-sm text-gray-600">Price: ${product?.price?.toFixed(2)}</p>
                <p className="text-sm text-gray-600">Business: {product.businessName}</p>
                <div className="mt-4 flex space-x-4">
                  <button
                    onClick={() => startEditing(product)}
                    className="flex-1 py-2 bg-blue-500 text-white rounded-lg hover:bg-blue-600 transition"
                  >
                    Edit
                  </button>
                  <button
                    onClick={() => handleDeleteProduct(product.id)}
                    className="flex-1 py-2 bg-red-500 text-white rounded-lg hover:bg-red-600 transition"
                  >
                    Delete
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

export default ProductManagement;