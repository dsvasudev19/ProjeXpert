// import { useState } from 'react';
// import { useNavigate, Link } from 'react-router-dom';

// function Login() {
//   const [username, setUsername] = useState('');
//   const [password, setPassword] = useState('');
//   const [role, setRole] = useState('CUSTOMER');
//   const navigate = useNavigate();

//   const handleLogin = async () => {
//     try {
//       const response = await fetch('http://localhost:3000/login', {
//         method: 'POST',
//         headers: { 'Content-Type': 'application/json' },
//         body: JSON.stringify({ username, password, role }),
//       });
//       const data = await response.json();
//       if (response.ok) {
//         localStorage.setItem('token', data.token);
//         localStorage.setItem('role', data.user.role);
//         localStorage.setItem('userId', data.user.id); // Store userId
//         alert('Login successful! Token saved.');
//         if (data.user.role === 'ADMIN') {
//           navigate('/admin');
//         } else if (data.user.role === 'VENDOR') {
//           navigate('/vendor');
//         } else {
//           navigate('/businesses');
//         }
//       } else {
//         alert(data.error || 'Login failed');
//       }
//     } catch (error) {
//       alert('Error: ' + error.message);
//     }
//   };

//   return (
//     <div className="w-full max-w-md bg-white p-8 rounded-lg shadow-lg">
//       <h2 className="text-2xl font-bold text-center text-green-800 mb-6">Login to Village Commerce</h2>
//       <div className="space-y-4">
//         <div>
//           <label className="block text-sm font-medium text-gray-700">Username</label>
//           <input
//             type="text"
//             value={username}
//             onChange={(e) => setUsername(e.target.value)}
//             className="mt-1 w-full p-2 border border-gray-300 rounded focus:ring-2 focus:ring-orange-400"
//             placeholder="Enter username"
//           />
//         </div>
//         <div>
//           <label className="block text-sm font-medium text-gray-700">Password</label>
//           <input
//             type="password"
//             value={password}
//             onChange={(e) => setPassword(e.target.value)}
//             className="mt-1 w-full p-2 border border-gray-300 rounded focus:ring-2 focus:ring-orange-400"
//             placeholder="Enter password"
//           />
//         </div>
//         <div>
//           <label className="block text-sm font-medium text-gray-700">Role</label>
//           <select
//             value={role}
//             onChange={(e) => setRole(e.target.value)}
//             className="mt-1 w-full p-2 border border-gray-300 rounded focus:ring-2 focus:ring-orange-400"
//           >
//             <option value="CUSTOMER">Customer</option>
//             <option value="VENDOR">Vendor</option>
//             <option value="ADMIN">Admin</option>
//           </select>
//         </div>
//         <button
//           onClick={handleLogin}
//           className="w-full py-2 bg-orange-500 text-white rounded hover:bg-orange-600 transition"
//         >
//           Login
//         </button>
//         <p className="text-center text-sm text-gray-600">
//           No account? <Link to="/register" className="text-orange-500 hover:underline">Register</Link>
//         </p>
//       </div>
//     </div>
//   );
// }

// export default Login;

import { useState, useEffect } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import axios from 'axios';

function Login() {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  const navigate = useNavigate();

  const handleLogin = async (e) => {
    e.preventDefault();
    if (!username || !password) {
      setError('Username and password are required.');
      return;
    }
    try {
      const response = await axios.post('http://localhost:3000/login', {
        username,
        password,
      });
      localStorage.setItem('token', response.data.token);
      localStorage.setItem('role', response.data.user.role);
      localStorage.setItem('userId', response.data.user.id);
      setSuccess('Login successful! Redirecting...');
      setTimeout(() => {
        if (response.data.user.role === 'ADMIN') {
          navigate('/admin');
        } else if (response.data.user.role === 'VENDOR') {
          navigate('/vendor');
        } else {
          navigate('/businesses');
        }
      }, 2000);
    } catch (error) {
      setError(error.response?.data?.error || 'Login failed.');
    }
  };

  // Clear messages after 3 seconds
  useEffect(() => {
    if (error || success) {
      const timer = setTimeout(() => {
        setError('');
        setSuccess('');
      }, 3000);
      return () => clearTimeout(timer);
    }
  }, [error, success]);

  return (
    <div className="min-h-screen bg-gray-100 flex items-center justify-center py-12 px-4 sm:px-6 lg:px-8">
      <div className="w-full max-w-md bg-white p-8 rounded-lg shadow-xl">
        <h2 className="text-3xl font-extrabold text-center text-green-800 mb-8">
          Login to Village Commerce
        </h2>

        {/* Messages */}
        {error && (
          <div className="mb-6 p-4 bg-red-100 text-red-700 rounded-lg text-center">
            {error}
          </div>
        )}
        {success && (
          <div className="mb-6 p-4 bg-green-100 text-green-700 rounded-lg text-center">
            {success}
          </div>
        )}

        {/* Form */}
        <form onSubmit={handleLogin} className="space-y-6">
          <div>
            <label htmlFor="username" className="block text-sm font-medium text-gray-700">
              Username
            </label>
            <input
              id="username"
              type="text"
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              className="mt-1 w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-400 focus:outline-none"
              placeholder="Enter your username"
              required
              aria-required="true"
            />
          </div>
          <div>
            <label htmlFor="password" className="block text-sm font-medium text-gray-700">
              Password
            </label>
            <input
              id="password"
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="mt-1 w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-400 focus:outline-none"
              placeholder="Enter your password"
              required
              aria-required="true"
            />
          </div>
          <button
            type="submit"
            className="w-full py-3 bg-orange-500 text-white rounded-lg hover:bg-orange-600 transition disabled:bg-orange-300"
            disabled={!username || !password}
          >
            Login
          </button>
        </form>
        <p className="mt-6 text-center text-sm text-gray-600">
          No account?{' '}
          <Link to="/register" className="text-orange-500 hover:underline">
            Register
          </Link>
        </p>
      </div>
    </div>
  );
}

export default Login;