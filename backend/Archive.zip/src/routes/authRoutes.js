const express = require('express');
const router = express.Router();
const { 
    register, 
    login, 
    logout, 
    getUserByToken,
    generateAccessTokenBasedOnRefreshToken,
    generateForgotPasswordToken,
    resetPassword,
    getUserForResetPassword
} = require('../controllers/authController');

// User registration route
router.post('/register', register);

// User login route
router.post('/login', login);

// User logout route
router.post('/logout', logout);

router.get("/user/token",getUserByToken);

router.post("/refresh-token",generateAccessTokenBasedOnRefreshToken)

router.post("/forgot-password",generateForgotPasswordToken)

router.post("/reset-password",resetPassword)

router.get("/reset-password",getUserForResetPassword)

module.exports = router;
