module.exports={
  "development": {
    "username": "root",
    "password": null,
    "database": "projexpert",
    "host": "127.0.0.1",
    "dialect": "mysql"
  },
  "test": {
    "username": "root",
    "password": null,
    "database": "database_test",
    "host": "127.0.0.1",
    "dialect": "mysql"
  },
  "production": {
    "username": "intevxxe_projexpert",
    "password": "3R?[{MifIQ[x",
    "database": "intevxxe_projexpert",
    "host": "127.0.0.1",
    "dialect": "mysql"
  }
}
